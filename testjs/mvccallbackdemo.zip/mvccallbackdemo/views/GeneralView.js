class GeneralView {
    static showMessage(title, msg, extra) {
        console.log(title);
        console.log('--------');
        console.log(msg);
        console.log('additional info: ', extra)
    }
}

module.exports = GeneralView;