<template>
  <div class="text-2xl font-bold">
      Not found
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>